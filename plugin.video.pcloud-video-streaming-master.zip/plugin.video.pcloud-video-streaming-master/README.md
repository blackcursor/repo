Kodi video plugin that provides video streaming from a https://www.pcloud.com (free or paid) account.

For Kodi Matrix (19.x) and greater.
